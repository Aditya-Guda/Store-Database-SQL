import mysql.connector
import tkinter as tk
from tkinter import *

root = tk.Tk()
root.geometry("550x300")
root.title("shippers List")

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="Ea@abdul!",
  database="sql_store"
)
my_cursor = mydb.cursor()

title_label = Label(root, text="List", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=1, pady="5")
e = Label(root, width=10, text='Shipper Id', borderwidth=2, relief='ridge', anchor='w', bg='light blue')
e.grid(row=1, column=0)
e = Label(root, width=10, text='Name', borderwidth=2, relief='ridge', anchor='w', bg='light blue')
e.grid(row=1, column=1)

my_cursor.execute("SELECT * FROM shippers limit 0,10")
i = 2
for shippers in my_cursor:
    for j in range(len(shippers)):
        e = Entry(root, width=10, fg='blue')
        e.grid(row=i, column=j)
        e.insert(END, shippers[j])
    i = i+1

root.mainloop()