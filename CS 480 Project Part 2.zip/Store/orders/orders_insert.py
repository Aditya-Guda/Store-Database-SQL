import tkinter as tk
import mysql.connector
from tkinter import *

root = tk.Tk()
root.geometry("300x300")
root.title("DBMS Login Page")


mydb = mysql.connector.connect(
        host="localhost",
        database="sql_store",
        user="root",
        passwd="Ea@abdul!"
)

my_cursor = mydb.cursor()

# insert orders to database
def insert_orders():
    sql_command = "INSERT INTO orders (order_id, customer_id, status, shipper_id) Values (%s, %s, %s, %s)"
    values = (order_id_box.get(), customer_id_box.get(), status_box.get(), shipper_id_box.get())
    my_cursor.execute(sql_command, values)
    # Commit the changes to the database
    mydb.commit()
    clear_fields()

# clear the boxes
def clear_fields():
    order_id_box.delete(0, "end")
    customer_id_box.delete(0, "end")
    status_box.delete(0, "end")
    shipper_id_box.delete(0, "end")

# create a label
title_label = Label(root, text="Insert", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=2, pady="10")

# create main form
order_id_label = Label(root, text="Order ID").grid(row=1, column=0, sticky=W, padx=10)
customer_id_label = Label(root, text="Customer ID").grid (row=2, column=0, sticky=W, padx=10)
status_label = Label(root, text="Status").grid (row=3, column=0, sticky=W, padx=10)
shipper_id_label = Label(root, text="Shipper ID").grid (row=4, column=0, sticky=W, padx=10)

# create entry boxes
order_id_box = Entry(root)
order_id_box.grid(row=1, column=1)
customer_id_box = Entry(root)
customer_id_box.grid(row=2, column=1, pady=5)
status_box = Entry(root)
status_box.grid(row=3, column=1, pady=5)
shipper_id_box = Entry(root)
shipper_id_box.grid(row=4, column=1, pady=5)

# create button
insert_button = Button(root, text="Orders", command=insert_orders)
insert_button.grid(row=5, column=0, padx=5, pady=5)
clear_fields_button = Button(root, text="Clear", command=clear_fields)
clear_fields_button.grid(row=5, column=1)

# my_cursor.execute("SELECT * FROM orders")
# for db in my_cursor:
#     print(db)

root.mainloop()