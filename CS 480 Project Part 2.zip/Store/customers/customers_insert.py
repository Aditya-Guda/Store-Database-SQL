import tkinter as tk
import mysql.connector
from tkinter import *

root = tk.Tk()
root.geometry("340x260")
root.title("Customer Insert")


mydb = mysql.connector.connect(
        host="localhost",
        database="sql_store",
        user="root",
        passwd="Ea@abdul!"
)

my_cursor = mydb.cursor()

# insert customer to database
def insert_customer():
    sql_command = "INSERT INTO customers (first_name, last_name, city, state) Values (%s, %s, %s, %s)"
    values = (first_name_box.get(), last_name_box.get(), city_box.get(), state_box.get())
    my_cursor.execute(sql_command, values)
    # Commit the changes to the database
    mydb.commit()
    clear_fields()

# clear the boxes
def clear_fields():
    first_name_box.delete(0, "end")
    last_name_box.delete(0, "end")
    city_box.delete(0, "end")
    state_box.delete(0, "end")

# create a label
title_label = Label(root, text="Insert", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=2, pady="10")

# create main form
first_name_label = Label(root, text="First Name").grid(row=1, column=0, sticky=W, padx=10)
last_name_label = Label(root, text="Last Name").grid (row=2, column=0, sticky=W, padx=10)
city_label = Label(root, text="City").grid (row=3, column=0, sticky=W, padx=10)
state_label = Label(root, text="State").grid (row=4, column=0, sticky=W, padx=10)

# create entry boxes
first_name_box = Entry(root)
first_name_box.grid(row=1, column=1)
last_name_box = Entry(root)
last_name_box.grid(row=2, column=1, pady=5)
city_box = Entry(root)
city_box.grid(row=3, column=1, pady=5)
state_box = Entry(root)
state_box.grid(row=4, column=1, pady=5)

# create button
insert_button = Button(root, text="Insert Customer", command=insert_customer)
insert_button.grid(row=5, column=0, padx=5, pady=5)
clear_fields_button = Button(root, text="Clear", command=clear_fields)
clear_fields_button.grid(row=5, column=1)

my_cursor.execute("SELECT * FROM customers")
for db in my_cursor:
    print(db)

root.mainloop()