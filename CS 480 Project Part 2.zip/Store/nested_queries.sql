USE sql_store;

-- select customers who lives in IL
-- SELECT
-- 	customer_id,
-- 	first_name,
--     last_name
-- FROM customers
-- 	WHERE customer_id IN
--     (SELECT customer_id
--      FROM customers
--      WHERE state = "IL") 

-- selcet customers who their products are either shipped or delivered
-- SELECT
-- 	c.customer_id,
-- 	c.first_name,
--     c.last_name
-- FROM customers c
-- 	WHERE c.customer_id IN
--     (SELECT o.customer_id
--      FROM orders o
--      WHERE o.status > 1)


-- select customers who ordered more than two items 
-- SELECT
-- 	c.customer_id,
-- 	c.first_name,
--     c.last_name
-- FROM customers c
-- 	WHERE c.customer_id IN
--     (SELECT o.customer_id
--      FROM orders o
--      WHERE o.status IN (
-- 		SELECT ot.order_id
--      FROM order_items ot
--      WHERE ot.quantity > 2))


-- select customers that order apple
-- SELECT
-- 	c.customer_id,
-- 	c.first_name,
--     c.last_name
-- FROM customers c
-- 	WHERE c.customer_id IN
--     (SELECT o.customer_id
--      FROM orders o
--      WHERE o.order_id IN (
-- 		SELECT ot.order_id
--      FROM order_items ot
--      WHERE ot.product_id = 1))


-- select customers that their unit price is more tha $5 
-- SELECT
-- 	c.customer_id,
-- 	c.first_name,
--     c.last_name
-- FROM customers c
-- 	WHERE c.customer_id IN
--     (SELECT o.customer_id
--      FROM orders o
--      WHERE o.order_id IN (
-- 		SELECT ot.order_id
--      FROM order_items ot
--      WHERE ot.unit_price > 5))


-- select custome-- rs who
-- SELECT
-- 	c.customer_id,
-- 	c.first_name,
--     c.last_name
-- FROM customers c
-- 	WHERE c.customer_id IN
--     (SELECT o.customer_id
--      FROM orders o
--      WHERE o.order_id IN (
-- 		SELECT ot.order_id
--      FROM order_items ot
--      WHERE ot.product_id IN (
-- 			SELECT p.product_id
-- 			FROM products p
-- 			WHERE p.quantity_in_stock > 10)))
      
      
-- select products that has a qauntity of more than 15
-- SELECT 
-- 		P.product_id,
-- 		p.name, 
-- 		p.quantity_in_stock
-- FROM products p
-- WHERE p.product_id IN (
-- SELECT p.product_id
-- FROM products p
-- WHERE p.quantity_in_stock > 15)

     

