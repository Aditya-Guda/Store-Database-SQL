import tkinter as tk
import mysql.connector
from tkinter import *

root = tk.Tk()
root.geometry("350x300")
root.title("Order Status")


mydb = mysql.connector.connect(
        host="localhost",
        database="sql_store",
        user="root",
        passwd="Ea@abdul!"
)

my_cursor = mydb.cursor()

# insert customer to database
def insert_order_statuses():
    sql_command = "INSERT INTO order_statuses (order_status_id, name) Values (%s, %s)"
    values = (order_status_id_box.get(), name_box.get())
    my_cursor.execute(sql_command, values)
    # Commit the changes to the database
    mydb.commit()
    clear_fields()

# clear the boxes
def clear_fields():
    shipper_id_box.delete(0, "end")
    name_box.delete(0, "end")

# create a label
title_label = Label(root, text="Insert", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=2, pady="10")

# create main form
order_statuses_id_label = Label(root, text="Order Status ID").grid (row=1, column=0, sticky=W, padx=10)
name_label = Label(root, text="Name").grid(row=2, column=0, sticky=W, padx=10)

# create entry boxes
order_status_id_box = Entry(root)
order_status_id_box.grid(row=1, column=1)
name_box = Entry(root)
name_box.grid(row=2, column=1, pady=5)

# create button
insert_button = Button(root, text="Order Status", command=insert_order_statuses)
insert_button.grid(row=5, column=0, padx=5, pady=5)
clear_fields_button = Button(root, text="Clear", command=clear_fields)
clear_fields_button.grid(row=5, column=1)

# my_cursor.execute("SELECT * FROM order statuses")
# for db in my_cursor:
#     print(db)

root.mainloop()