import tkinter as tk
import mysql.connector
from tkinter import *

root = tk.Tk()
root.geometry("350x300")
root.title("Order Items")


mydb = mysql.connector.connect(
        host="localhost",
        database="sql_store",
        user="root",
        passwd="Ea@abdul!"
)

my_cursor = mydb.cursor()

# insert customer to database
def insert_customer():
    sql_command = "INSERT INTO order_items (order_id, product_id, quantity, unit_price) Values (%s, %s, %s, %s)"
    values = (order_id_box.get(), product_id_box.get(), quantity_box.get(), unit_price_box.get())
    my_cursor.execute(sql_command, values)
    # Commit the changes to the database
    mydb.commit()
    clear_fields()

# clear the boxes
def clear_fields():
    order_id_box.delete(0, "end")
    product_id_box.delete(0, "end")
    quantity_box.delete(0, "end")
    unit_price_box.delete(0, "end")

# create a label
title_label = Label(root, text="Insert", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=2, pady="10")

# create main form
order_id_label = Label(root, text="Order ID").grid(row=1, column=0, sticky=W, padx=10)
product_id_label = Label(root, text="Product ID").grid (row=2, column=0, sticky=W, padx=10)
quantity_label = Label(root, text="Quantity").grid (row=3, column=0, sticky=W, padx=10)
unit_price_label = Label(root, text="Unit Price").grid (row=4, column=0, sticky=W, padx=10)

# create entry boxes
order_id_box = Entry(root)
order_id_box.grid(row=1, column=1)
product_id_box = Entry(root)
product_id_box.grid(row=2, column=1, pady=5)
quantity_box= Entry(root)
quantity_box.grid(row=3, column=1, pady=5)
unit_price_box = Entry(root)
unit_price_box.grid(row=4, column=1, pady=5)

# create button
insert_button = Button(root, text="Insert Order Items", command=insert_customer)
insert_button.grid(row=5, column=0, padx=5, pady=5)
clear_fields_button = Button(root, text="Clear", command=clear_fields)
clear_fields_button.grid(row=5, column=1)

my_cursor.execute("SELECT * FROM order_items")
for db in my_cursor:
    print(db)

root.mainloop()