import mysql.connector
import tkinter as tk
from tkinter import *

root = tk.Tk()
root.geometry("550x300")
root.title("Order Items List")

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="Ea@abdul!",
  database="sql_store"
)
my_cursor = mydb.cursor()

title_label = Label(root, text="List", font=("Helvetica", 28))
title_label.grid(row=0, column=0, columnspan=1, pady="5")
e = Label(root, width=10, text='Order Id', borderwidth=2, relief='ridge', anchor='w', bg='light blue')
e.grid(row=1, column=0)
e = Label(root, width=10, text='Product ID', borderwidth=2, relief='ridge', anchor='w', bg='light blue')
e.grid(row=1, column=1)
e = Label(root, width=10, text='Quality', borderwidth=2, relief='ridge', anchor='w', bg='light blue')
e.grid(row=1, column=2)


my_cursor.execute("SELECT * FROM order_items limit 0,10")
i = 2
for order_items in my_cursor:
    for j in range(len(order_items)):
        e = Entry(root, width=10, fg='blue')
        e.grid(row=i, column=j)
        e.insert(END, order_items[j])
    i = i+1

root.mainloop()